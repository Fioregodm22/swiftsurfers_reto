//
//  SwiftSurfersRETOApp.swift
//  SwiftSurfersRETO
//
//  Created by Salvador Ancer on 14/10/25.
//

import SwiftUI

@main
struct SwiftSurfersRETOApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                    LoginView()
                
            }
        }
    }
}
